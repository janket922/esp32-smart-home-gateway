MQTT image validation tool (third-party binary package)

Original author and distribution source: not identified.
Included for reproducing this project's MQTT image receiver demonstration.
This software is not authored by this firmware project's maintainer.
No license or author notice was found in the provided application directory.
Existing copyright metadata in executables and Qt libraries is preserved.

Extract the complete package before running the receiver executable.
Keep the runtime DLLs and plugin folders beside the executables.
The original config.ini and config_rx.ini are deliberately excluded because
these binary Qt settings files contain saved connection parameters.
Enter your broker, port, receiver client ID, username, password and video topic
in the application. Use a receiver client ID distinct from the ESP32 publisher.
This package does not include the original application's source code.
